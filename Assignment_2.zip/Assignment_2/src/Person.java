public class Person {
    private String name;


    Person(String initialName)
    {

    }

    public Person()
    {

    }

    public void setName( String fullName) {

    }

    public String getName() {
        return null;
    }

    public String toString() {
        return null;

    }
}