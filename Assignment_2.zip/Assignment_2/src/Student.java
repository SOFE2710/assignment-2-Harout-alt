import java.util.Vector;

public class Student extends Person{
    private String id;
    private String name;
    private Vector<Course> courses = new Vector<Course>();

    public Student( String id, String name) {
        this.name = name;
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public String getId()
    {
        return id;
    }

    public void registerFor(Course course) {
        courses.add(course);
    }

    public boolean isRegisteredInCourse(Course course) {
        int i = 0;

        while (i < courses.size())
        {
            if (course.getCode() == (courses.get(i).getCode()) && course.getNumber() == courses.get(i).getNumber()) {
                return true;
            }
            i++;
        }
        return false;
    }

    public boolean isRegisteredInCourse(int course) {
        int i = 0;

        while (i < courses.size())
        {
            if (course.getCode().equals(courses.get(i).getCode())) {
                if (course.getNumber() == courses.get(i).getNumber()){
                    return true;
                }
            }
            i++;
        }
        return false;
    }

    @Override
    public String toString()
    {

        System.out.println(this.id + " " + this.name);
        System.out.print("Courses that are registered: ");

        for (int i = 0; i < courses.size(); i++) {
            System.out.print(courses.get(i).getCode() + " " + courses.get(i).getNumber());

        }
        System.out.println();

        return " ";
    }

}


